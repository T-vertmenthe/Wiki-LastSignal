# Futur Radio

Owner: Thomas LICATA
Status: Not started

La radio subira des changements, à commencer par son design qui comprendra le Scanner.

# Fréquences

- Les attaques seront bien plus diverses avec des caractéristiques différentes.
- Un descriptif des attaques s’affichera dans l’espace réservé à cet usage.

# Scanner

- Le scanner sera implémenté dans la radio et il aura une utilité en combat, il permettra de voir les faiblesses et résistances des monstres, afin d‘adapter la stratégie du joueur en fonction du monstre.

# Oscillations (Joueur et Ennemi)

- Les oscillations seront complètements modulables de manière plus fluide.