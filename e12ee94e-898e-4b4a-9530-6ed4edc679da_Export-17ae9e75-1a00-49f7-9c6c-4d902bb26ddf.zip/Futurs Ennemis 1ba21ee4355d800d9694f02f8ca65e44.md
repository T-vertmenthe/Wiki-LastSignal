# Futurs Ennemis

Owner: Thomas LICATA
Status: Not started

Les ennemis, points primordiaux du jeu, seront mis à jour avec des nouveautés au niveau gameplay et immersion.

# Nouveaux monstres

- Des nouveaux monstres avec des effets différents seront implémentés, ce qui va faire varier le gameplay et éviter la redondance

# Comportements des monstres

- Les monstres bénéficieront de divers comportements afin d’ajouter de la surprise et de l’imprévisibilité pour commencer à ajouter le côté angoissant qui fait parti des intentions du jeu