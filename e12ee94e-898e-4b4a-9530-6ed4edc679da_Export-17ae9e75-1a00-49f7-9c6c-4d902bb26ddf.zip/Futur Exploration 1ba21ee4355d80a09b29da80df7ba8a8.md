# Futur Exploration

Owner: Thomas LICATA
Status: Not started

L’exploration sera mise à jour afin qu’elle interagisse beaucoup plus avec le joueur et qu’elle le récompense.

# Interactions avec l’environnement

- Le joueur pourra interagir avec des éléments du décor, comme rentrer dans des salles, trouver des coffres, etc.

# Récompenses

- Les récompenses feront leur apparition et pourront donner des items variés, qui seront bénéfiques pour le joueur.