# Futurs Items

Owner: Thomas LICATA
Status: Not started

Afin de récompenser le joueur des différents exploits qu’il va réaliser, et également faire varier le gameplay, les items vont être plus conséquents.

# Nouveaux items

- De nouveaux items feront leur apparition, qu’ils servent dans l’exploration ou le combat, ils permettront d’ajouter un contenu assez conséquent pour faire explorer de nouveaux horizons au joueur.