# Synopsis

Owner: Ethan CHAINTRON, Thomas LICATA
Verification: Expired
Tags: Onboarding, Story
Status: Done

En 1983, une guerre nucléaire éclate, tuant des milliers de civils. Seules certaines personnes proches des abris parviennent à survivre.

Vingt ans plus tard,
[Ivanov Belinski](Ivanov%20Belinski%2019021ee4355d80339a82f32c11a82668.md), un ancien opérateur radio de l’URSS, sort d’un [bunker](Bunker%201b821ee4355d805997a0c7c6f2d4c0c9.md) militaire dans l’espoir de retrouver sa [fille](Petite%20fille%20(nom%20provisoire)%2019021ee4355d80538ebecb0c9be04517.md), dont il a été séparé. Au fil de ses recherches, il découvre un bunker émettant un signal de détresse. Sans autre piste, il s’y engouffre, espérant être enfin réuni avec elle.