# Second Playable

Owner: Thomas LICATA
Status: Not started

Ici sont groupés les différentes Features qui seront présentes dans la Second Playable.

Elles constituent les priorités annexes, mais qui seront nécessaires à l’intensification du fun dans Last Signal.

[Futur Bunker](Futur%20Bunker%201ba21ee4355d8058b160e89dc55f48c6.md)

[Futur Radio ](Futur%20Radio%201ba21ee4355d80b390eff95fe034a858.md)

[Futur Petite Fille ](Futur%20Petite%20Fille%201ba21ee4355d805e9fccc7387252efc3.md)

[Futurs Ennemis](Futurs%20Ennemis%201ba21ee4355d800d9694f02f8ca65e44.md)

[Futurs Items](Futurs%20Items%201ba21ee4355d80cfa7ddefa7d4e60c42.md)

[Futur Combat](Futur%20Combat%201ba21ee4355d80b9a06cfd73cdbe06d3.md)

[Futur Exploration](Futur%20Exploration%201ba21ee4355d80a09b29da80df7ba8a8.md)