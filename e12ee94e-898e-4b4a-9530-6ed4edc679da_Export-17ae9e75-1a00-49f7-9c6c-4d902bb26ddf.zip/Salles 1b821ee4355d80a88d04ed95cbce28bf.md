# Salles

Owner: Ethan CHAINTRON, Thomas LICATA
Verification: Expired
Tags: Entities, Gameplay, items
Status: Done

Les salles se trouvent dans chaque étage du [bunker](Bunker%201b821ee4355d805997a0c7c6f2d4c0c9.md), elles sont adaptées à chaque environnement. 

# Contenu des salles

## Objectifs d’Ivanov

[Ivanov](Ivanov%20Belinski%2019021ee4355d80339a82f32c11a82668.md) est soumis à plusieurs objectifs qu’il doit résoudre pour parcourir le bunker et arriver au bout de son périlleux voyage.

## Ennemis

Les [ennemis](Ennemis%201b921ee4355d8070b3f0ee80e3efb429.md) vont au fur et à mesure être de plus en plus puissants durant l’aventure d’Ivanov, marquant la progression du joueur au cœur du bunker.

## Récompenses

Chaque salle possède des récompenses qui varient entre chaque partie du joueur, les items sont générés aléatoirement, mais toujours adaptés au niveau du personnage.

**Exemple :** Si le joueur est vers la fin du jeu avec des équipements avancés, les objets générés seront en adéquation avec son niveau, et inversement.