# Futur Petite Fille

Owner: Thomas LICATA
Status: Not started

La Petite Fille subira des changements afin de plonger le joueur encore plus profondément dans l’histoire.

# Prénom de la petite Fille

- La Petite Fille aura enfin un prénom pour la rendre plus reconnaissable.

# Visuel

- Elle aura également son propre charadesign.