# Futur Bunker

Owner: Thomas LICATA
Status: Not started

Le bunker, lieu dans lequel se passe l’histoire, sera amélioré afin de lui donner plus de profondeur et améliorer l’immersion. Mais il aura également des changements avec des impacts dans le gameplay. 

# Environnements

- Le futur Bunker comptera des environnements qui impacteront certaines aptitudes d’Ivanov, pareillement pour les salles.

# Effets d’environnements

- Des effets d’attaques pourront être nerf ou buff selon l’environnement.