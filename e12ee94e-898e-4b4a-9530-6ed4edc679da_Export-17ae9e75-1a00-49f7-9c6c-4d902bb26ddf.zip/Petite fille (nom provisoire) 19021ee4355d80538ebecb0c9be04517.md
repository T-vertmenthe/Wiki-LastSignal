# Petite fille (nom provisoire)

Owner: Ethan CHAINTRON, Thomas LICATA
Verification: Expired
Tags: Entities, Story
Status: Done

# Histoire

**Elle s’appelle [insérer le nom].**

Lors de la guerre de 1983, elle n’avait que 7 ans. Séparée de son père, Ivanov, dans le chaos et la panique, elle s’est retrouvée seule, obligée de survivre dans un monde en ruines. Elle savait à peine lire et écrire, mais a dû apprendre à se cacher, à fuir, à se battre… à vivre sans lui.

**[insérer le nom]** est devenue l’espoir d’Ivanov. Elle est la raison pour laquelle, des années plus tard, il parcourt ce bunker abandonné, risquant tout pour la retrouver. Chaque pas qu’il fait, chaque signal qu’il capte sur sa radio, c’est pour elle. Mais qu’est-elle devenue ?

A-t-elle survécu à cet enfer souterrain ? Est-elle encore humaine après tant d’années passées dans les ténèbres ? Et surtout… rêve-t-elle encore de retrouver son père ?

Dans *Last Signal*, c’est au joueur de suivre les traces d’**[insérer le nom]**. De découvrir son histoire. Et, peut-être, de réunir une dernière fois une fille et son père.