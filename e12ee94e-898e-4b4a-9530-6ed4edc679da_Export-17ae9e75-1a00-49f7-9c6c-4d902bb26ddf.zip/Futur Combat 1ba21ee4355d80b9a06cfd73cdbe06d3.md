# Futur Combat

Owner: Thomas LICATA
Status: Not started

Le combat, redondant à première vue, va être amélioré avec l’ajout d’un outil dynamique conséquent : le QTE

# QTE

- Le gros ajout du système de combat sera le QTE, qui sera propre à chaque attaque avec différents patterns et types afin de donner un côté unique aux attaques.
- Il permettra d’ajouter du dynamisme aux combats et ainsi le rendre moins ennuyant, en plus de cela, l’efficacité des attaques sera impactée par la réussite ou non du QTE, ajoutant un défi supplémentaire pour le joueur lors des combats.